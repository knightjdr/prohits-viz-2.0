import React from 'react';

const Recommendations = () => (
  <div>
    Recommendations
  </div>
);

export default Recommendations;
