import React from 'react';

const Tools = () => (
  <div>
    Tools
  </div>
);

export default Tools;
