import React from 'react';

const Visualization = () => (
  <div>
    Visualization
  </div>
);

export default Visualization;
