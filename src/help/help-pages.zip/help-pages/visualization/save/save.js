import React from 'react';

const Save = () => (
  <div>
    Save
  </div>
);

export default Save;
