import React from 'react';

const Archive = () => (
  <div>
    Archive
  </div>
);

export default Archive;
