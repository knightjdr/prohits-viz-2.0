import React from 'react';

const FileFormat = () => (
  <div>
    File format
  </div>
);

export default FileFormat;
