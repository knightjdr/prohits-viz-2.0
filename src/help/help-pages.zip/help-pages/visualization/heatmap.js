import React from 'react';

const Heatmap = () => (
  <div>
    Heatmap
  </div>
);

export default Heatmap;
